<head>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<?php
include 'classes/View.class.php';
$view = new View();
$view->showView();




