<?php
    include 'classes/RegexPattern.php';
    include 'classes/DataParser.php';
    include 'classes/AccountingData.php';
    include 'classes/Table.php';
    include 'classes/Input.php';
    include 'classes/Output.php';
    include 'classes/File.php';
    Input::File();
    Output::parsedFile();
    




